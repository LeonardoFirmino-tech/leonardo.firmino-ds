import java.util.Random;
import java.util.Scanner;

public class Ex8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        int numero = rand.nextInt(100) + 1;
        int chute;

        do {
            System.out.print("Chute: ");
            chute = sc.nextInt();

            if (chute > numero) {
                System.out.println("Menor!");
            } else if (chute < numero) {
                System.out.println("Maior!");
            }
        } while (chute != numero);

        System.out.println("Acertou!");
    }
}