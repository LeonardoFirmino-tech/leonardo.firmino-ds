import java.util.Scanner;

public class Ex2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o CPF: ");
        String cpf = sc.nextLine();

        if (cpf.length() == 11 && cpf.matches("\\d+")) {
            System.out.println("CPF válido (formato)");
        } else {
            System.out.println("CPF inválido");
        }
    }
}