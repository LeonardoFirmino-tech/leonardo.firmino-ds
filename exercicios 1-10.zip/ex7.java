import java.util.Scanner;

public class Ex7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double total = 0;
        int opcao;

        do {
            System.out.println("1 - Adicionar item");
            System.out.println("2 - Ver total");
            System.out.println("3 - Sair");
            opcao = sc.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Valor do item: ");
                    total += sc.nextDouble();
                    break;
                case 2:
                    System.out.println("Total: R$ " + total);
                    break;
            }
        } while (opcao != 3);
    }
}