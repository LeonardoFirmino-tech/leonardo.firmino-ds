import java.util.Scanner;

public class Ex6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nums = new int[5];

        for (int i = 0; i < 5; i++) {
            nums[i] = sc.nextInt();
        }

        System.out.println("Pares:");
        for (int n : nums) {
            if (n % 2 == 0) System.out.print(n + " ");
        }

        System.out.println("\nÍmpares:");
        for (int n : nums) {
            if (n % 2 != 0) System.out.print(n + " ");
        }
    }
}