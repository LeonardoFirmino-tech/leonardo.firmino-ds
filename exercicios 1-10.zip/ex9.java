import java.util.ArrayList;
import java.util.Scanner;

public class Ex9 {
    static ArrayList<String> alunos = new ArrayList<>();

    public static void cadastrarAluno(String nome) {
        alunos.add(nome);
    }

    public static void listarAlunos() {
        for (String a : alunos) {
            System.out.println(a);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        cadastrarAluno("João");
        cadastrarAluno("Maria");

        listarAlunos();
    }
}