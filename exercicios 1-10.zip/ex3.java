import java.util.Scanner;

public class Ex3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String user = "admin";
        String pass = "1234";

        int tentativas = 0;

        while (tentativas < 3) {
            System.out.print("Usuário: ");
            String u = sc.nextLine();
            System.out.print("Senha: ");
            String p = sc.nextLine();

            if (u.equals(user) && p.equals(pass)) {
                System.out.println("Acesso permitido");
                return;
            }

            tentativas++;
            System.out.println("Erro! Tentativas restantes: " + (3 - tentativas));
        }

        System.out.println("Conta bloqueada");
    }
}