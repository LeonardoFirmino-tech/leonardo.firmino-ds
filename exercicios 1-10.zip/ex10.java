import java.util.Scanner;

public class Ex10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] produtos = new String[10];
        int[] quantidades = new int[10];
        int count = 0;

        int opcao;

        do {
            System.out.println("1 - Adicionar produto");
            System.out.println("2 - Listar produtos");
            System.out.println("3 - Sair");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome: ");
                    produtos[count] = sc.nextLine();
                    System.out.print("Quantidade: ");
                    quantidades[count] = sc.nextInt();
                    count++;
                    break;

                case 2:
                    for (int i = 0; i < count; i++) {
                        System.out.println(produtos[i] + " - " + quantidades[i]);
                    }
                    break;
            }

        } while (opcao != 3);
    }
}