import java.util.Scanner;

public class Ex1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] nums = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite um número: ");
            nums[i] = sc.nextInt();
        }

        int maior = nums[0], menor = nums[0], soma = 0;

        for (int n : nums) {
            soma += n;
            if (n > maior) maior = n;
            if (n < menor) menor = n;
        }

        double media = soma / 5.0;

        System.out.println("Média: " + media);
        System.out.println("Maior: " + maior);
        System.out.println("Menor: " + menor);
    }
}