import java.util.Scanner;

public class Ex4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o valor: ");
        int valor = sc.nextInt();

        int[] notas = {100, 50, 20, 10, 5, 2};

        for (int nota : notas) {
            int qtd = valor / nota;
            valor %= nota;
            System.out.println(qtd + " nota(s) de " + nota);
        }
    }
}