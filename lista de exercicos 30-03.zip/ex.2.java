import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Digite o CPF: ");
        String cpf = sc.nextLine();

        if (cpf.length() == 11) {
            System.out.println("CPF valido (formato)");
        } else {
            System.out.println("CPF invalido");
        }

        sc.close();
    }
}