import java.util.Scanner;

public class Main {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String senhaCorreta = "1234";
		int tentativas = 0;

		while (tentativas < 3) {
			System.out.print("Digite a senha: ");
			String senha = sc.nextLine();

			if (senha.equals(senhaCorreta)) {
				System.out.println("Acesso liberado");
				break;
			} else {
				System.out.println("Senha errada");
			}

			tentativas++;
		}

		if (tentativas == 3) {
			System.out.println("Bloqueado");
		}

		sc.close();
	}
}