import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[5];
        int soma = 0;

        for (int i = 0; i < 5; i++) {
            System.out.print("Digite um numero: ");
            numeros[i] = sc.nextInt();
            soma += numeros[i];
        }

        int maior = numeros[0];
        int menor = numeros[0];

        for (int i = 0; i < 5; i++) {
            if (numeros[i] > maior) maior = numeros[i];
            if (numeros[i] < menor) menor = numeros[i];
        }

        double media = soma / 5.0;

        System.out.println("Media: " + media);
        System.out.println("Maior: " + maior);
        System.out.println("Menor: " + menor);

        sc.close();
    }
}