import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a primeira nota:");
        double n1 = sc.nextDouble();

        System.out.println("Digite a segunda nota:");
        double n2 = sc.nextDouble();

        System.out.println("Digite a terceira nota:");
        double n3 = sc.nextDouble();

        double media = (n1 + n2 + n3) / 3;

        if (media >= 7) {
            System.out.println("Aluno aprovado");
        } else if (media >= 5) {
            System.out.println("Aluno em recuperação");
        } else {
            System.out.println("Aluno reprovado");
        }

    }
}