import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro numero:");
        double a = sc.nextDouble();

        System.out.println("Digite o segundo numero:");
        double b = sc.nextDouble();

        System.out.println("Digite o operador (+ - * /):");
        char op = sc.next().charAt(0);

        if (op == '+') {
            System.out.println("Resultado: " + (a + b));
        } else if (op == '-') {
            System.out.println("Resultado: " + (a - b));
        } else if (op == '*') {
            System.out.println("Resultado: " + (a * b));
        } else if (op == '/') {
            System.out.println("Resultado: " + (a / b));
        }

    }
}