import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite sua altura:");
        double h = sc.nextDouble();

        System.out.println("Digite seu sexo (M/F):");
        char sexo = sc.next().charAt(0);

        double peso;

        if (sexo == 'M' || sexo == 'm') {
            peso = (72.7 * h) - 58;
        } else {
            peso = (62.1 * h) - 44.7;
        }

        System.out.println("Peso ideal: " + peso);

    }
}