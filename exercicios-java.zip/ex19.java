import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o numero 1:");
        int a = sc.nextInt();

        System.out.println("Digite o numero 2:");
        int b = sc.nextInt();

        System.out.println("Digite o numero 3:");
        int c = sc.nextInt();

        int menor = a;

        if (b < menor) menor = b;
        if (c < menor) menor = c;

        System.out.println("O menor numero é: " + menor);

    }
}