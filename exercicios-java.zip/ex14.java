import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a distancia da viagem:");
        double distancia = sc.nextDouble();

        System.out.println("Digite o consumo do carro (km/L):");
        double consumo = sc.nextDouble();

        double litros = distancia / consumo;

        System.out.println("Litros gastos: " + litros);

    }
}