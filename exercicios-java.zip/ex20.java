import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o lado 1:");
        double a = sc.nextDouble();

        System.out.println("Digite o lado 2:");
        double b = sc.nextDouble();

        System.out.println("Digite o lado 3:");
        double c = sc.nextDouble();

        if (a + b > c && a + c > b && b + c > a) {

            if (a == b && b == c) {
                System.out.println("Triangulo equilatero");
            } else if (a == b || a == c || b == c) {
                System.out.println("Triangulo isosceles");
            } else {
                System.out.println("Triangulo escaleno");
            }

        } else {
            System.out.println("Nao forma um triangulo");
        }

    }
}