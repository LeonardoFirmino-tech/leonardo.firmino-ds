import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a nota:");
        double nota = sc.nextDouble();

        System.out.println("Digite a frequencia (%):");
        double freq = sc.nextDouble();

        if (nota >= 7 && freq >= 75) {
            System.out.println("Aluno aprovado");
        } else {
            System.out.println("Aluno reprovado");
        }

    }
}