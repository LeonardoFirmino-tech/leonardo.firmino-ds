import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o primeiro numero:");
        int a = sc.nextInt();

        System.out.println("Digite o segundo numero:");
        int b = sc.nextInt();

        if (a % b == 0) {
            System.out.println("O primeiro numero é multiplo do segundo");
        } else {
            System.out.println("Nao é multiplo");
        }

    }
}