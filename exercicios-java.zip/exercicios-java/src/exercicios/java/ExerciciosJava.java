/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercicios.java;

import java.util.Scanner;

/**
 *
 * @author CAMARGO
 */
public class ExerciciosJava {
public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        System.out.print("leia um numero: ");
        char a = teclado.next().charAt(0);

        System.out.println("Você digitou: "+a);
    int number = a;
    
    if (number % 2 == 0) {
      System.out.println(number + "é par");
    } else {
      System.out.println(number + "é impar");
    }
  }
}

