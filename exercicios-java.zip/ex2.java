import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o numero 1:");
        double a = sc.nextDouble();

        System.out.println("Digite o numero 2:");
        double b = sc.nextDouble();

        if (a > b) {
            System.out.println("O maior numero é: " + a);
        } else if (b > a) {
            System.out.println("O maior numero é: " + b);
        } else {
            System.out.println("Os numeros são iguais");
        }

    }
}