import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite um numero:");
        double n = sc.nextDouble();

        if (n > 0) {
            System.out.println("Numero positivo");
        } else if (n < 0) {
            System.out.println("Numero negativo");
        } else {
            System.out.println("Numero zero");
        }

    }
}