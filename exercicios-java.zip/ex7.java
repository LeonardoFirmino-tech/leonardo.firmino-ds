import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite a temperatura em Celsius:");
        double c = sc.nextDouble();

        double f = (c * 9/5) + 32;

        System.out.println("Temperatura em Fahrenheit: " + f);

    }
}